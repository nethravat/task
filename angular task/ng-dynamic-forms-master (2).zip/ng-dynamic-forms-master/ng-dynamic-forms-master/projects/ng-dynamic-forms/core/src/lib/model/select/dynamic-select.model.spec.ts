import { waitForAsync } from "@angular/core/testing";
import { DYNAMIC_FORM_CONTROL_TYPE_SELECT, DynamicSelectModel } from "./dynamic-select.model";

describe("DynamicSelectModel test suite", () => {
    let model: DynamicSelectModel<string>;
    const config = {
        id: "select",
        multiple: false,
        options: [
            {
                value: "1",
                label: "One"
            },
            {
                value: "2",
                label: "Two"
            }
        ]
    };

    beforeEach(() => model = new DynamicSelectModel(config));

    it("should initialize correctly", () => {
        expect(model.disabled).toBe(false);
        expect(model.filterable).toBe(false);
        expect(model.hidden).toBe(false);
        expect(model.id).toEqual(config.id);
        expect(model.label).toBeNull();
        expect(model.multiple).toBe(config.multiple);
        expect(model.options.length).toBe(config.options.length);
        expect(model.placeholder).toEqual("");
        expect(model.type).toEqual(DYNAMIC_FORM_CONTROL_TYPE_SELECT);
        expect(model.value).toBeNull();
        expect(model.compareWithFn).toBe(Object.is);
        expect(model.disabledChanges).toBeDefined();
        expect(model.valueChanges).toBeDefined();
    });

    it("should get and set text property correctly", () => {
        expect(model.get(0).text).toEqual("One");

        model.get(0).text = "Eins";

        expect(model.get(0).text).toEqual("Eins");
    });

    it("should correctly create options Observable", waitForAsync(() => {
        model.options$.subscribe(options => {
            expect(options.length).toBe(config.options.length);
        });
    }));

    it("should add another option", () => {
        const option = {label: "test option", value: "test-option"};

        model.add(option);

        expect(model.options.length).toBe(config.options.length + 1);
        expect(model.get(model.options.length - 1).value).toEqual(option.value);
    });

    it("should insert another option", () => {
        const option = {label: "test option", value: "test-option"};
        const index = 1;

        model.insert(index, option);

        expect(model.options.length).toBe(config.options.length + 1);
        expect(model.get(index).value).toEqual(option.value);
    });

    it("should remove a given option", () => {
        model.remove(1);

        expect(model.options.length).toBe(config.options.length - 1);
    });

    it("should get the correct option", () => {
        expect(model.get(0)).toEqual(model.options[0]);
        expect(model.get(1)).toEqual(model.options[1]);
    });

    it("should select correct option", () => {
        model.select(1);

        expect(model.value).toEqual(model.get(1).value);
    });

    it("should select multiple options", () => {
        model.multiple = true;
        model.select(0, 1);

        expect(model.value).toEqual([model.get(0).value, model.get(1).value]);
    });

    it("should serialize correctly", () => {
        const json = JSON.parse(JSON.stringify(model));

        expect(json.id).toEqual(model.id);
        expect(json.options.length).toBe(model.options.length);
        expect(json.value).toBe(model.value);
        expect(json.type).toEqual(DYNAMIC_FORM_CONTROL_TYPE_SELECT);
    });
});
