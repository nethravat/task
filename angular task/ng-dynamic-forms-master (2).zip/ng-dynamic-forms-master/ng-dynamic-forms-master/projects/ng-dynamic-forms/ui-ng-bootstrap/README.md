# NG Dynamic Forms NG Bootstrap UI

## Installation
```
npm i @ng-dynamic-forms/ui-ng-bootstrap -S
```

## Import
```ts
@NgModule({

    imports: [DynamicFormsNGBootstrapUIModule]
})

export class AppModule {}
```

## Usage

with **`DynamicNGBootstrapFormComponent`**:
```ts
<form [formGroup]="myFormGroup">

    <dynamic-ng-bootstrap-form [group]="myFormGroup"
                               [model]="myFormModel"></dynamic-ng-bootstrap-form>
</form>
```

with **`DynamicNGBootstrapFormControlComponent`**:
```ts
<form [formGroup]="myFormGroup">

    <dynamic-ng-bootstrap-form-control *ngFor="let controlModel of myFormModel"
                                       [group]="myFormGroup"
                                       [model]="controlModel"></dynamic-ng-bootstrap-form-control>
</form>
```

## Form Controls


## Resources

* [**API Documentation**](http://ng2-dynamic-forms.udos86.de/docs/ui-ng-bootstrap/)
* [**Live Sample**](http://ng2-dynamic-forms.udos86.de/sample/index.aot.html#ng-bootstrap-sample-form) 
