export const PRIME_NG_TEMPLATE_DIRECTIVES = new Map<string, string>([
    ["itemTemplate", "itemTemplate"],
    ["selectedItemTemplate", "selectedItemTemplate"]
]);
