#!/bin/bash

npm publish ./dist/ng-dynamic-forms/core/
npm publish ./dist/ng-dynamic-forms/ui-basic/
npm publish ./dist/ng-dynamic-forms/ui-bootstrap/
npm publish ./dist/ng-dynamic-forms/ui-foundation/
npm publish ./dist/ng-dynamic-forms/ui-ionic/
npm publish ./dist/ng-dynamic-forms/ui-material/
npm publish ./dist/ng-dynamic-forms/ui-ng-bootstrap/
npm publish ./dist/ng-dynamic-forms/ui-ngx-bootstrap/
npm publish ./dist/ng-dynamic-forms/ui-primeng/
